# -*- coding: utf-8 -*-


import urlparse, sys

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))

action = params.get('action')
name = params.get('name')
title = params.get('title')
year = params.get('year')
imdb = params.get('imdb')
tvdb = params.get('tvdb')
tmdb = params.get('tmdb')
season = params.get('season')
episode = params.get('episode')
tvshowtitle = params.get('tvshowtitle')
premiered = params.get('premiered')
url = params.get('url')
image = params.get('image')
meta = params.get('meta')
sub = params.get('sub')
select = params.get('select')
query = params.get('query')
source = params.get('source')
content = params.get('content')
rtype = params.get('rtype')
content_type = params.get('content_type')

windowedtrailer = params.get('windowedtrailer')
windowedtrailer = int(windowedtrailer) if windowedtrailer in ('0', '1') else 0
